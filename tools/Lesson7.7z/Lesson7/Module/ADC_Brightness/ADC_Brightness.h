//******************************************************************************
//*
//* This Information Proprietary  To Kong Studio Corporation
//*
//******************************************************************************
//*
//*           Copyright (c) 2015 Kong Studio Corporation
//*                  ALL RIGHTS RESERVED
//*
//******************************************************************************
    
//******************************************************************************
//* FILE NAME: ADC_Brightness.h
//*
//* DESCRIPTION: STM8S Practice example
//*
//* ORIGINATOR: Konglittle
//*
//* DATE: 2015-04-19
//*
//******************************************************************************
#ifndef _ADC_BRIGHTNESS_H
#define _ADC_BRIGHTNESS_H


void ADC_BrightnessTask(void);
#endif